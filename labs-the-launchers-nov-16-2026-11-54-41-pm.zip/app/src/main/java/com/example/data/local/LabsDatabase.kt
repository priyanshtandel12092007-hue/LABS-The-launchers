package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LauncherProfileEntity::class,
        PinnedAppEntity::class,
        HiddenAppEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class LabsDatabase : RoomDatabase() {
    abstract fun launcherDao(): LauncherDao

    companion object {
        @Volatile
        private var instance: LabsDatabase? = null

        fun getInstance(context: Context): LabsDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    LabsDatabase::class.java,
                    "labs_launcher.db",
                ).build().also { instance = it }
            }
        }
    }
}
