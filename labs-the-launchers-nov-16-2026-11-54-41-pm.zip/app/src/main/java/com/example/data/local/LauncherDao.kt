package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LauncherDao {
    @Query("SELECT * FROM launcher_profiles ORDER BY isPreset DESC, updatedAt DESC")
    fun observeProfiles(): Flow<List<LauncherProfileEntity>>

    @Query("SELECT COUNT(*) FROM launcher_profiles")
    suspend fun getProfileCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: LauncherProfileEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertProfilesIfAbsent(profiles: List<LauncherProfileEntity>)

    @Query("DELETE FROM launcher_profiles WHERE id = :profileId AND isPreset = 0")
    suspend fun deleteCustomProfile(profileId: String)

    @Query("SELECT * FROM pinned_apps ORDER BY isDock ASC, position ASC")
    fun observePinnedApps(): Flow<List<PinnedAppEntity>>

    @Query("SELECT COUNT(*) FROM pinned_apps")
    suspend fun getPinnedCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPinnedApp(pinned: PinnedAppEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPinnedApps(pinned: List<PinnedAppEntity>)

    @Query("DELETE FROM pinned_apps WHERE packageName = :packageName")
    suspend fun removePinnedApp(packageName: String)

    @Query("SELECT packageName FROM hidden_apps")
    fun observeHiddenPackages(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun hideApp(hidden: HiddenAppEntity)

    @Query("DELETE FROM hidden_apps WHERE packageName = :packageName")
    suspend fun unhideApp(packageName: String)
}
