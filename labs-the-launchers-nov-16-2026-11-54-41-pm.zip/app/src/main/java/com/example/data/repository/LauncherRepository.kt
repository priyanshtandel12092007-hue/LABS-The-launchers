package com.example.data.repository

import com.example.data.local.HiddenAppEntity
import com.example.data.local.LauncherDao
import com.example.data.local.LauncherPreferences
import com.example.data.local.PinnedAppEntity
import com.example.data.local.toDomain
import com.example.data.local.toEntity
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherProfile
import com.example.data.model.StarterPresets
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

class LauncherRepository(
    private val dao: LauncherDao,
    private val prefs: LauncherPreferences,
) {
    val profiles: Flow<List<LauncherProfile>> = dao.observeProfiles().map { list ->
        if (list.isEmpty()) StarterPresets.all else list.map { it.toDomain() }
    }

    val activeProfileId: Flow<String> = prefs.activeProfileId

    val activeProfile: Flow<LauncherProfile> = combine(profiles, activeProfileId) { all, id ->
        all.find { it.id == id } ?: all.firstOrNull() ?: StarterPresets.labsDefault
    }

    val pinnedApps: Flow<List<PinnedAppEntity>> = dao.observePinnedApps()

    val hiddenPackageNames: Flow<Set<String>> = dao.observeHiddenPackages().map { it.toSet() }

    val isDefaultBannerDismissed: Flow<Boolean> = prefs.isDefaultBannerDismissed

    suspend fun ensureSeeded(installedApps: List<InstalledApp>, ownPackageName: String) {
        dao.insertProfilesIfAbsent(StarterPresets.all.map { it.toEntity() })

        val alreadySeeded = prefs.isHomeAutoSeeded.first()
        if (!alreadySeeded && dao.getPinnedCount() == 0 && installedApps.isNotEmpty()) {
            val candidates = installedApps.filter { it.packageName != ownPackageName }
            val dockPriority = listOf("dialer", "phone", "messaging", "messages", "mms", "chrome", "browser", "camera")
            val dockApps = mutableListOf<InstalledApp>()
            for (keyword in dockPriority) {
                val found = candidates.firstOrNull { app ->
                    (app.packageName.contains(keyword, ignoreCase = true) ||
                        app.label.contains(keyword, ignoreCase = true)) &&
                        dockApps.none { it.packageName == app.packageName }
                }
                if (found != null && dockApps.size < 4) {
                    dockApps.add(found)
                }
            }
            for (app in candidates) {
                if (dockApps.size >= 4) break
                if (dockApps.none { it.packageName == app.packageName }) {
                    dockApps.add(app)
                }
            }

            val homeApps = candidates
                .filter { candidate -> dockApps.none { it.packageName == candidate.packageName } }
                .take(12)

            val entities = buildList {
                dockApps.forEachIndexed { idx, app ->
                    add(PinnedAppEntity(packageName = app.packageName, isDock = true, position = idx))
                }
                homeApps.forEachIndexed { idx, app ->
                    add(PinnedAppEntity(packageName = app.packageName, isDock = false, position = idx))
                }
            }
            if (entities.isNotEmpty()) {
                dao.upsertPinnedApps(entities)
            }
            prefs.markHomeAutoSeeded()
        }
    }

    suspend fun selectProfile(profileId: String) {
        prefs.setActiveProfileId(profileId)
    }

    suspend fun saveProfile(profile: LauncherProfile, activateImmediately: Boolean = true): LauncherProfile {
        val toSave = if (profile.isPreset) {
            profile.copy(
                id = UUID.randomUUID().toString(),
                isPreset = false,
                updatedAt = System.currentTimeMillis(),
            )
        } else {
            profile.copy(updatedAt = System.currentTimeMillis())
        }
        dao.upsertProfile(toSave.toEntity())
        if (activateImmediately) {
            prefs.setActiveProfileId(toSave.id)
        }
        return toSave
    }

    suspend fun saveProfileAsNew(name: String, baseProfile: LauncherProfile, activateImmediately: Boolean = true): LauncherProfile {
        val created = baseProfile.copy(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifEmpty { "Custom Launcher" },
            isPreset = false,
            updatedAt = System.currentTimeMillis(),
        )
        dao.upsertProfile(created.toEntity())
        if (activateImmediately) {
            prefs.setActiveProfileId(created.id)
        }
        return created
    }

    suspend fun deleteCustomProfile(profileId: String) {
        val currentId = prefs.activeProfileId.first()
        dao.deleteCustomProfile(profileId)
        if (currentId == profileId) {
            prefs.setActiveProfileId(StarterPresets.ID_LABS_DEFAULT)
        }
    }

    suspend fun pinToHome(packageName: String) {
        val current = dao.observePinnedApps().first()
        val nextPos = (current.filter { !it.isDock }.maxOfOrNull { it.position } ?: -1) + 1
        dao.upsertPinnedApp(PinnedAppEntity(packageName = packageName, isDock = false, position = nextPos))
    }

    suspend fun pinToDock(packageName: String) {
        val current = dao.observePinnedApps().first()
        val dockApps = current.filter { it.isDock }
        if (dockApps.size >= 5 && dockApps.none { it.packageName == packageName }) {
            // Replace last slot or keep under 5
            dockApps.lastOrNull()?.let { dao.removePinnedApp(it.packageName) }
        }
        val nextPos = (dockApps.maxOfOrNull { it.position } ?: -1) + 1
        dao.upsertPinnedApp(PinnedAppEntity(packageName = packageName, isDock = true, position = nextPos))
    }

    suspend fun unpinApp(packageName: String) {
        dao.removePinnedApp(packageName)
    }

    suspend fun hideApp(packageName: String) {
        dao.hideApp(HiddenAppEntity(packageName))
        dao.removePinnedApp(packageName)
    }

    suspend fun unhideApp(packageName: String) {
        dao.unhideApp(packageName)
    }

    suspend fun dismissDefaultBanner() {
        prefs.setDefaultBannerDismissed(true)
    }
}
