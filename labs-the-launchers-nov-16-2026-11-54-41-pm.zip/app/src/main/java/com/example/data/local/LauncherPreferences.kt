package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.StarterPresets
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.labsDataStore: DataStore<Preferences> by preferencesDataStore(name = "labs_launcher_prefs")

class LauncherPreferences(private val context: Context) {

    private object Keys {
        val ACTIVE_PROFILE_ID = stringPreferencesKey("active_profile_id")
        val HOME_AUTO_SEEDED = booleanPreferencesKey("home_auto_seeded")
        val DEFAULT_BANNER_DISMISSED = booleanPreferencesKey("default_banner_dismissed")
    }

    val activeProfileId: Flow<String> = context.labsDataStore.data.map { prefs ->
        prefs[Keys.ACTIVE_PROFILE_ID] ?: StarterPresets.ID_LABS_DEFAULT
    }

    val isHomeAutoSeeded: Flow<Boolean> = context.labsDataStore.data.map { prefs ->
        prefs[Keys.HOME_AUTO_SEEDED] ?: false
    }

    val isDefaultBannerDismissed: Flow<Boolean> = context.labsDataStore.data.map { prefs ->
        prefs[Keys.DEFAULT_BANNER_DISMISSED] ?: false
    }

    suspend fun setActiveProfileId(profileId: String) {
        context.labsDataStore.edit { prefs ->
            prefs[Keys.ACTIVE_PROFILE_ID] = profileId
        }
    }

    suspend fun markHomeAutoSeeded() {
        context.labsDataStore.edit { prefs ->
            prefs[Keys.HOME_AUTO_SEEDED] = true
        }
    }

    suspend fun setDefaultBannerDismissed(dismissed: Boolean) {
        context.labsDataStore.edit { prefs ->
            prefs[Keys.DEFAULT_BANNER_DISMISSED] = dismissed
        }
    }
}
