package com.example.data.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap

enum class ClockStyle(val displayName: String) {
    DIGITAL("Digital"),
    MINIMAL_SERIF("Minimal Serif"),
    ANALOG("Analog"),
}

enum class IconShape(val displayName: String) {
    CIRCLE("Circle"),
    SQUIRCLE("Squircle"),
    ROUNDED_SQUARE("Rounded Square"),
}

enum class BackgroundStyle(val displayName: String, val isLightSurface: Boolean) {
    SYSTEM_WALLPAPER("Live Wallpaper", false),
    PAPER_WARM("LABS Paper", true),
    OBSIDIAN_DARK("Obsidian Dark", false),
    SOLAR_GRADIENT("Solar Horizon", false),
    SAGE_MIST("Sage Mist", true),
    CUSTOM_SOLID("Custom Solid", false),
}

data class InstalledApp(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: ImageBitmap?,
    val isSystemApp: Boolean,
)

data class LauncherProfile(
    val id: String,
    val name: String,
    val isPreset: Boolean = false,
    val gridColumns: Int = 4,
    val gridRows: Int = 5,
    val iconSizeDp: Float = 54f,
    val showLabels: Boolean = true,
    val minimalistMode: Boolean = false,
    val iconShape: IconShape = IconShape.SQUIRCLE,
    val iconTintHex: Long = 0L,
    val iconTintOpacity: Float = 0.18f,
    val clockStyle: ClockStyle = ClockStyle.MINIMAL_SERIF,
    val accentColorHex: Long = 0xFFD94E28,
    val backgroundStyle: BackgroundStyle = BackgroundStyle.SYSTEM_WALLPAPER,
    val customBackgroundHex: Long = 0xFF1E222B,
    val wallpaperScrimAlpha: Float = 0.25f,
    val showSearchBar: Boolean = true,
    val showDock: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis(),
) {
    val accentColor: Color get() = Color(accentColorHex)
    val iconTintColor: Color? get() = if (iconTintHex == 0L) null else Color(iconTintHex)
    val customBackgroundColor: Color get() = Color(customBackgroundHex)

    val usesLightForegroundText: Boolean
        get() = when (backgroundStyle) {
            BackgroundStyle.PAPER_WARM, BackgroundStyle.SAGE_MIST -> false
            BackgroundStyle.CUSTOM_SOLID -> {
                val r = ((customBackgroundHex shr 16) and 0xFF) / 255f
                val g = ((customBackgroundHex shr 8) and 0xFF) / 255f
                val b = (customBackgroundHex and 0xFF) / 255f
                (0.299f * r + 0.587f * g + 0.114f * b) < 0.58f
            }
            else -> true
        }
}

object StarterPresets {
    const val ID_LABS_DEFAULT = "preset_labs_default"
    const val ID_MINIMAL_ROCKET = "preset_minimal_rocket"
    const val ID_CLEAN_GRID = "preset_clean_grid"

    val labsDefault = LauncherProfile(
        id = ID_LABS_DEFAULT,
        name = "LABS Default",
        isPreset = true,
        gridColumns = 4,
        gridRows = 5,
        iconSizeDp = 54f,
        showLabels = true,
        minimalistMode = false,
        iconShape = IconShape.SQUIRCLE,
        iconTintHex = 0xFFF3F0EA,
        iconTintOpacity = 0.85f,
        clockStyle = ClockStyle.MINIMAL_SERIF,
        accentColorHex = 0xFFD94E28,
        backgroundStyle = BackgroundStyle.PAPER_WARM,
        customBackgroundHex = 0xFFEAE6DF,
        wallpaperScrimAlpha = 0.2f,
        showSearchBar = true,
        showDock = true,
        updatedAt = 1L,
    )

    val minimalRocket = LauncherProfile(
        id = ID_MINIMAL_ROCKET,
        name = "Minimal Rocket",
        isPreset = true,
        gridColumns = 4,
        gridRows = 5,
        iconSizeDp = 48f,
        showLabels = true,
        minimalistMode = true,
        iconShape = IconShape.CIRCLE,
        iconTintHex = 0L,
        iconTintOpacity = 0f,
        clockStyle = ClockStyle.ANALOG,
        accentColorHex = 0xFFF59E0B,
        backgroundStyle = BackgroundStyle.OBSIDIAN_DARK,
        customBackgroundHex = 0xFF111317,
        wallpaperScrimAlpha = 0.35f,
        showSearchBar = true,
        showDock = true,
        updatedAt = 2L,
    )

    val cleanGrid = LauncherProfile(
        id = ID_CLEAN_GRID,
        name = "Clean Grid",
        isPreset = true,
        gridColumns = 5,
        gridRows = 6,
        iconSizeDp = 50f,
        showLabels = false,
        minimalistMode = false,
        iconShape = IconShape.ROUNDED_SQUARE,
        iconTintHex = 0xFF1D2432,
        iconTintOpacity = 0.45f,
        clockStyle = ClockStyle.DIGITAL,
        accentColorHex = 0xFF2563EB,
        backgroundStyle = BackgroundStyle.SYSTEM_WALLPAPER,
        customBackgroundHex = 0xFF1E222B,
        wallpaperScrimAlpha = 0.25f,
        showSearchBar = true,
        showDock = true,
        updatedAt = 3L,
    )

    val all: List<LauncherProfile> = listOf(labsDefault, minimalRocket, cleanGrid)
}

object StudioPalettes {
    val accentSwatches: List<Pair<String, Long>> = listOf(
        "Terracotta" to 0xFFD94E28,
        "Cobalt" to 0xFF2563EB,
        "Amber" to 0xFFF59E0B,
        "Emerald" to 0xFF10B981,
        "Crimson" to 0xFFE11D48,
        "Ink" to 0xFF18181B,
    )

    val iconTintSwatches: List<Pair<String, Long>> = listOf(
        "None" to 0L,
        "Paper" to 0xFFF3F0EA,
        "Obsidian" to 0xFF181B22,
        "Terracotta" to 0xFFD94E28,
        "Cobalt" to 0xFF2563EB,
        "Sage" to 0xFF5D7A64,
        "Amber" to 0xFFF59E0B,
    )

    val solidBackgroundSwatches: List<Pair<String, Long>> = listOf(
        "Slate" to 0xFF1E222B,
        "Forest" to 0xFF182820,
        "Burgundy" to 0xFF2B1820,
        "Cream" to 0xFFF4EFE6,
        "Sand" to 0xFFE2D8C8,
        "Midnight" to 0xFF0A0C10,
    )
}
