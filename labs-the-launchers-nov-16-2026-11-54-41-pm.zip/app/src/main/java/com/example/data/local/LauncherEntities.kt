package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.BackgroundStyle
import com.example.data.model.ClockStyle
import com.example.data.model.IconShape
import com.example.data.model.LauncherProfile

@Entity(tableName = "launcher_profiles")
data class LauncherProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val isPreset: Boolean,
    val gridColumns: Int,
    val gridRows: Int,
    val iconSizeDp: Float,
    val showLabels: Boolean,
    val minimalistMode: Boolean,
    val iconShape: String,
    val iconTintHex: Long,
    val iconTintOpacity: Float,
    val clockStyle: String,
    val accentColorHex: Long,
    val backgroundStyle: String,
    val customBackgroundHex: Long,
    val wallpaperScrimAlpha: Float,
    val showSearchBar: Boolean,
    val showDock: Boolean,
    val updatedAt: Long,
)

@Entity(tableName = "pinned_apps")
data class PinnedAppEntity(
    @PrimaryKey val packageName: String,
    val isDock: Boolean,
    val position: Int,
)

@Entity(tableName = "hidden_apps")
data class HiddenAppEntity(
    @PrimaryKey val packageName: String,
)

fun LauncherProfileEntity.toDomain(): LauncherProfile = LauncherProfile(
    id = id,
    name = name,
    isPreset = isPreset,
    gridColumns = gridColumns,
    gridRows = gridRows,
    iconSizeDp = iconSizeDp,
    showLabels = showLabels,
    minimalistMode = minimalistMode,
    iconShape = runCatching { IconShape.valueOf(iconShape) }.getOrDefault(IconShape.SQUIRCLE),
    iconTintHex = iconTintHex,
    iconTintOpacity = iconTintOpacity,
    clockStyle = runCatching { ClockStyle.valueOf(clockStyle) }.getOrDefault(ClockStyle.MINIMAL_SERIF),
    accentColorHex = accentColorHex,
    backgroundStyle = runCatching { BackgroundStyle.valueOf(backgroundStyle) }
        .getOrDefault(BackgroundStyle.SYSTEM_WALLPAPER),
    customBackgroundHex = customBackgroundHex,
    wallpaperScrimAlpha = wallpaperScrimAlpha,
    showSearchBar = showSearchBar,
    showDock = showDock,
    updatedAt = updatedAt,
)

fun LauncherProfile.toEntity(): LauncherProfileEntity = LauncherProfileEntity(
    id = id,
    name = name,
    isPreset = isPreset,
    gridColumns = gridColumns,
    gridRows = gridRows,
    iconSizeDp = iconSizeDp,
    showLabels = showLabels,
    minimalistMode = minimalistMode,
    iconShape = iconShape.name,
    iconTintHex = iconTintHex,
    iconTintOpacity = iconTintOpacity,
    clockStyle = clockStyle.name,
    accentColorHex = accentColorHex,
    backgroundStyle = backgroundStyle.name,
    customBackgroundHex = customBackgroundHex,
    wallpaperScrimAlpha = wallpaperScrimAlpha,
    showSearchBar = showSearchBar,
    showDock = showDock,
    updatedAt = updatedAt,
)
