package com.example

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.AppMode
import com.example.ui.LauncherViewModel
import com.example.ui.home.HomeLauncherScreen
import com.example.ui.studio.LauncherStudioScreen
import com.example.ui.theme.LabsTheme

class MainActivity : ComponentActivity() {

    private val launcherViewModel: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
        )

        setContent {
            val state by launcherViewModel.uiState.collectAsStateWithLifecycle()
            val lifecycleOwner = LocalLifecycleOwner.current

            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) {
                        launcherViewModel.refreshSystemState()
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                }
            }

            LaunchedEffect(state.statusMessage) {
                state.statusMessage?.let { msg ->
                    Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                    launcherViewModel.clearStatusMessage()
                }
            }

            val isStudioDark = state.appMode == AppMode.LAUNCHER_STUDIO &&
                state.studioDraftProfile.usesLightForegroundText
            val isHomeDark = state.appMode == AppMode.HOME_LAUNCHER &&
                state.activeProfile.usesLightForegroundText

            val useLightSystemBarIcons = if (state.appMode == AppMode.LAUNCHER_STUDIO) {
                !isStudioDark
            } else {
                !isHomeDark
            }

            LaunchedEffect(useLightSystemBarIcons) {
                val style = if (useLightSystemBarIcons) {
                    SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                } else {
                    SystemBarStyle.dark(Color.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }

            LabsTheme(
                darkTheme = isStudioDark,
                accentColor = if (state.appMode == AppMode.LAUNCHER_STUDIO) {
                    state.studioDraftProfile.accentColor
                } else {
                    state.activeProfile.accentColor
                },
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Crossfade(
                        targetState = state.appMode,
                        label = "labs_mode_transition",
                    ) { mode ->
                        when (mode) {
                            AppMode.HOME_LAUNCHER -> {
                                HomeLauncherScreen(
                                    state = state,
                                    onOpenStudio = launcherViewModel::openLauncherStudio,
                                    onOpenDrawer = launcherViewModel::openDrawer,
                                    onCloseDrawer = launcherViewModel::closeDrawer,
                                    onDrawerSearchChange = launcherViewModel::updateDrawerSearch,
                                    onToggleShowHidden = launcherViewModel::toggleShowHiddenInDrawer,
                                    onLaunchApp = launcherViewModel::launchApp,
                                    onAppLongClick = launcherViewModel::showAppActions,
                                    onDismissAppActions = launcherViewModel::dismissAppActions,
                                    onPinHome = launcherViewModel::pinToHome,
                                    onPinDock = launcherViewModel::pinToDock,
                                    onUnpinApp = launcherViewModel::unpinApp,
                                    onHideApp = launcherViewModel::hideApp,
                                    onUnhideApp = launcherViewModel::unhideApp,
                                    onOpenAppInfo = launcherViewModel::openAppInfo,
                                    onUninstallApp = launcherViewModel::uninstallApp,
                                    onOpenQuickMenu = launcherViewModel::openHomeQuickMenu,
                                    onCloseQuickMenu = launcherViewModel::closeHomeQuickMenu,
                                    onOpenWallpaperSheet = launcherViewModel::openWallpaperSheet,
                                    onCloseWallpaperSheet = launcherViewModel::closeWallpaperSheet,
                                    onQuickSelectBackground = launcherViewModel::quickSetBackground,
                                    onOpenSystemWallpaperPicker = launcherViewModel::openSystemWallpaperPicker,
                                    onSetDefaultLauncher = launcherViewModel::openHomeSettings,
                                    onDismissDefaultBanner = launcherViewModel::dismissDefaultBanner,
                                    onOpenSystemSettings = launcherViewModel::openSystemSettings,
                                )
                            }

                            AppMode.LAUNCHER_STUDIO -> {
                                LauncherStudioScreen(
                                    state = state,
                                    onUpdateDraft = launcherViewModel::updateDraft,
                                    onSelectProfile = launcherViewModel::selectProfile,
                                    onApplyToHome = { launcherViewModel.applyDraftToHome(goHome = true) },
                                    onSaveAsNewProfile = launcherViewModel::saveDraftAsNewProfile,
                                    onDeleteProfile = launcherViewModel::deleteProfile,
                                    onSetDefaultLauncher = launcherViewModel::openHomeSettings,
                                    onOpenSystemWallpaperPicker = launcherViewModel::openSystemWallpaperPicker,
                                    onBackToHome = launcherViewModel::returnToHomeLauncher,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            launcherViewModel.handleHomeButtonIntent()
        }
    }
}
