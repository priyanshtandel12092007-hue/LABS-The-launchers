package com.example.ui.drawer

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherProfile
import com.example.ui.components.toComposeShape
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianDark
import com.example.ui.theme.PaperWarm
import com.example.ui.theme.SpaceGroteskFontFamily
import kotlinx.coroutines.launch

private val ALPHABET = listOf("#") + ('A'..'Z').map { it.toString() }

private sealed interface DrawerRowItem {
    data class Header(val letter: String) : DrawerRowItem
    data class AppEntry(val app: InstalledApp, val isHidden: Boolean) : DrawerRowItem
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppDrawerOverlay(
    apps: List<InstalledApp>,
    hiddenPackages: Set<String>,
    pinnedHomePackages: Set<String>,
    pinnedDockPackages: Set<String>,
    profile: LauncherProfile,
    searchQuery: String,
    focusSearchOnOpen: Boolean,
    showHiddenApps: Boolean,
    onSearchChange: (String) -> Unit,
    onToggleShowHidden: () -> Unit,
    onAppClick: (InstalledApp) -> Unit,
    onAppLongClick: (InstalledApp) -> Unit,
    onClose: () -> Unit,
) {
    BackHandler(onBack = onClose)

    val isLight = !profile.usesLightForegroundText
    val surfaceBg = if (isLight) PaperWarm.copy(alpha = 0.97f) else ObsidianDark.copy(alpha = 0.95f)
    val contentColor = if (isLight) Color(0xFF151412) else Color(0xFFF6F5F2)
    val mutedColor = if (isLight) Color(0xFF5C5852) else Color(0xFF9DA3AE)

    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(focusSearchOnOpen) {
        if (focusSearchOnOpen) {
            runCatching { focusRequester.requestFocus() }
        }
    }

    val filteredApps = remember(apps, hiddenPackages, searchQuery, showHiddenApps) {
        apps.filter { app ->
            val hiddenMatch = if (showHiddenApps) true else app.packageName !in hiddenPackages
            val queryMatch = searchQuery.isBlank() ||
                app.label.contains(searchQuery, ignoreCase = true) ||
                app.packageName.contains(searchQuery, ignoreCase = true)
            hiddenMatch && queryMatch
        }
    }

    val drawerRows = remember(filteredApps, hiddenPackages) {
        val grouped = filteredApps.groupBy { app ->
            val first = app.label.firstOrNull()?.uppercaseChar() ?: '#'
            if (first in 'A'..'Z') first.toString() else "#"
        }
        val orderedKeys = grouped.keys.sortedWith(compareBy { if (it == "#") "~" else it })
        buildList {
            for (letter in orderedKeys) {
                add(DrawerRowItem.Header(letter))
                grouped[letter].orEmpty().forEach { app ->
                    add(DrawerRowItem.AppEntry(app, app.packageName in hiddenPackages))
                }
            }
        }
    }

    val letterIndexMap = remember(drawerRows) {
        buildMap {
            drawerRows.forEachIndexed { index, item ->
                if (item is DrawerRowItem.Header) {
                    put(item.letter, index)
                }
            }
        }
    }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    var activeScrubLetter by remember { mutableStateOf<String?>(null) }

    val topPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = surfaceBg,
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = topPadding + 8.dp, bottom = bottomPadding),
            ) {
                // Top Header + Close Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "ALL APPS · ${filteredApps.size}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.sp,
                        letterSpacing = 1.2.sp,
                        color = mutedColor,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (hiddenPackages.isNotEmpty()) {
                            FilterChip(
                                selected = showHiddenApps,
                                onClick = onToggleShowHidden,
                                label = {
                                    Text(
                                        text = if (showHiddenApps) "Showing Hidden" else "Hidden (${hiddenPackages.size})",
                                        fontSize = 11.sp,
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.VisibilityOff,
                                        contentDescription = "Toggle hidden apps",
                                        modifier = Modifier.size(16.dp),
                                    )
                                },
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        IconButton(
                            onClick = onClose,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("close_drawer_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.KeyboardArrowDown,
                                contentDescription = "Close App Drawer",
                                tint = contentColor,
                            )
                        }
                    }
                }

                // Search Field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .focusRequester(focusRequester)
                        .testTag("drawer_search_input"),
                    placeholder = {
                        Text(
                            text = "Search apps…",
                            color = mutedColor,
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Search",
                            tint = profile.accentColor,
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Clear search",
                                    tint = mutedColor,
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            filteredApps.firstOrNull()?.let(onAppClick)
                        },
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = contentColor,
                        unfocusedTextColor = contentColor,
                        focusedBorderColor = profile.accentColor,
                        unfocusedBorderColor = mutedColor.copy(alpha = 0.35f),
                        focusedContainerColor = contentColor.copy(alpha = 0.05f),
                        unfocusedContainerColor = contentColor.copy(alpha = 0.04f),
                    ),
                )

                // App List + A-Z Quick Scroll Rail
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    if (filteredApps.isEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(32.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Apps,
                                contentDescription = null,
                                tint = mutedColor,
                                modifier = Modifier.size(44.dp),
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No matching apps",
                                style = MaterialTheme.typography.titleMedium,
                                color = contentColor,
                            )
                            Text(
                                text = "Try clearing the search query or check hidden apps.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = mutedColor,
                            )
                        }
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(end = 34.dp),
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                end = 8.dp,
                                top = 6.dp,
                                bottom = 24.dp,
                            ),
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            items(
                                items = drawerRows,
                                key = { item ->
                                    when (item) {
                                        is DrawerRowItem.Header -> "hdr_${item.letter}"
                                        is DrawerRowItem.AppEntry -> "app_${item.app.packageName}_${item.app.activityName}"
                                    }
                                },
                            ) { item ->
                                when (item) {
                                    is DrawerRowItem.Header -> {
                                        Text(
                                            text = item.letter,
                                            fontFamily = SpaceGroteskFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = profile.accentColor,
                                            modifier = Modifier.padding(
                                                start = 6.dp,
                                                top = 12.dp,
                                                bottom = 4.dp,
                                            ),
                                        )
                                    }
                                    is DrawerRowItem.AppEntry -> {
                                        val app = item.app
                                        val badgeText = when {
                                            item.isHidden -> "Hidden"
                                            app.packageName in pinnedDockPackages -> "Dock"
                                            app.packageName in pinnedHomePackages -> "Home"
                                            else -> null
                                        }
                                        val shape = profile.iconShape.toComposeShape()
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .defaultMinSize(minHeight = 56.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .combinedClickable(
                                                    onClick = { onAppClick(app) },
                                                    onLongClick = { onAppLongClick(app) },
                                                )
                                                .padding(horizontal = 8.dp, vertical = 8.dp)
                                                .testTag("drawer_app_${app.packageName}"),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(42.dp)
                                                    .clip(shape)
                                                    .background(
                                                        profile.iconTintColor?.copy(
                                                            alpha = profile.iconTintOpacity.coerceIn(0.15f, 0.85f),
                                                        ) ?: Color.Transparent,
                                                    ),
                                                contentAlignment = Alignment.Center,
                                            ) {
                                                if (app.icon != null) {
                                                    Image(
                                                        bitmap = app.icon,
                                                        contentDescription = app.label,
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .padding(if (profile.iconTintColor != null) 4.dp else 0.dp)
                                                            .clip(shape),
                                                        contentScale = ContentScale.Crop,
                                                    )
                                                } else {
                                                    Icon(
                                                        imageVector = Icons.Rounded.Apps,
                                                        contentDescription = app.label,
                                                        tint = profile.accentColor,
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.width(14.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = app.label,
                                                    fontWeight = FontWeight.Medium,
                                                    fontSize = 15.sp,
                                                    color = if (item.isHidden) mutedColor else contentColor,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            }
                                            if (badgeText != null) {
                                                Surface(
                                                    shape = RoundedCornerShape(50),
                                                    color = profile.accentColor.copy(alpha = 0.14f),
                                                ) {
                                                    Text(
                                                        text = badgeText,
                                                        fontFamily = JetBrainsMonoFontFamily,
                                                        fontSize = 10.sp,
                                                        color = profile.accentColor,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // A-Z Quick Scroll Rail
                        AzQuickScrollRail(
                            availableLetters = letterIndexMap.keys,
                            accentColor = profile.accentColor,
                            mutedColor = mutedColor,
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 4.dp, top = 8.dp, bottom = 16.dp),
                            onLetterSelected = { letter ->
                                activeScrubLetter = letter
                                val targetIndex = letterIndexMap[letter] ?: return@AzQuickScrollRail
                                coroutineScope.launch {
                                    listState.scrollToItem(targetIndex)
                                }
                            },
                            onScrubEnd = {
                                activeScrubLetter = null
                            },
                        )
                    }

                    // Active Scrubbing Loupe
                    activeScrubLetter?.let { letter ->
                        Surface(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(76.dp),
                            shape = CircleShape,
                            color = profile.accentColor,
                            shadowElevation = 6.dp,
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = letter,
                                    fontFamily = SpaceGroteskFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 32.sp,
                                    color = Color.White,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AzQuickScrollRail(
    availableLetters: Set<String>,
    accentColor: Color,
    mutedColor: Color,
    onLetterSelected: (String) -> Unit,
    onScrubEnd: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var railHeightPx by remember { mutableStateOf(1) }

    fun resolveLetterAt(y: Float): String {
        val ratio = (y / railHeightPx.toFloat()).coerceIn(0f, 0.999f)
        val idx = (ratio * ALPHABET.size).toInt().coerceIn(0, ALPHABET.lastIndex)
        val direct = ALPHABET[idx]
        if (direct in availableLetters) return direct
        // Nearest available letter
        return availableLetters.minByOrNull { candidate ->
            val candidateIdx = ALPHABET.indexOf(candidate).takeIf { it >= 0 } ?: 0
            kotlin.math.abs(candidateIdx - idx)
        } ?: direct
    }

    Column(
        modifier = modifier
            .width(28.dp)
            .fillMaxHeight()
            .onSizeChanged { railHeightPx = it.height.coerceAtLeast(1) }
            .pointerInput(availableLetters) {
                detectTapGestures { offset ->
                    val letter = resolveLetterAt(offset.y)
                    onLetterSelected(letter)
                    onScrubEnd()
                }
            }
            .pointerInput(availableLetters) {
                detectDragGestures(
                    onDragStart = { offset ->
                        onLetterSelected(resolveLetterAt(offset.y))
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        onLetterSelected(resolveLetterAt(change.position.y))
                    },
                    onDragEnd = onScrubEnd,
                    onDragCancel = onScrubEnd,
                )
            }
            .testTag("az_quick_scroll_rail"),
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ALPHABET.forEach { letter ->
            val isAvailable = letter in availableLetters
            Text(
                text = letter,
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = if (isAvailable) FontWeight.Bold else FontWeight.Normal,
                fontSize = 9.sp,
                color = if (isAvailable) accentColor else mutedColor.copy(alpha = 0.4f),
            )
        }
    }
}
