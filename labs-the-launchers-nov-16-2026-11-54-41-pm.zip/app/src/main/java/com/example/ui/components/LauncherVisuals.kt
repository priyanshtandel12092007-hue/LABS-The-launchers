package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Dock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BackgroundStyle
import com.example.data.model.ClockStyle
import com.example.data.model.IconShape
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherProfile
import com.example.ui.theme.InkBlack
import com.example.ui.theme.InkMuted
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianDark
import com.example.ui.theme.PaperWarm
import com.example.ui.theme.PlayfairDisplayFontFamily
import com.example.ui.theme.PlusJakartaSansFontFamily
import com.example.ui.theme.SageBottom
import com.example.ui.theme.SageTop
import com.example.ui.theme.SnowWhite
import com.example.ui.theme.SolarBottom
import com.example.ui.theme.SolarMid
import com.example.ui.theme.SolarTop
import com.example.ui.theme.SpaceGroteskFontFamily
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun IconShape.toComposeShape(): Shape = when (this) {
    IconShape.CIRCLE -> CircleShape
    IconShape.SQUIRCLE -> RoundedCornerShape(percent = 32)
    IconShape.ROUNDED_SQUARE -> RoundedCornerShape(12.dp)
}

@Composable
fun LauncherBackgroundSurface(
    profile: LauncherProfile,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val bgModifier = when (profile.backgroundStyle) {
        BackgroundStyle.SYSTEM_WALLPAPER -> {
            Modifier.background(Color.Black.copy(alpha = profile.wallpaperScrimAlpha.coerceIn(0f, 0.7f)))
        }
        BackgroundStyle.PAPER_WARM -> {
            Modifier
                .background(PaperWarm)
                .drawBehind {
                    val grain = Color(0xFFD5CEC2)
                    val w = size.width
                    val h = size.height
                    for (i in 0..14) {
                        val y = (h / 15f) * (i + 0.5f)
                        val xStart = ((i * 73) % 100) / 100f * w * 0.6f
                        drawLine(
                            color = grain.copy(alpha = 0.45f),
                            start = Offset(xStart, y),
                            end = Offset(xStart + w * 0.25f, y + 6f),
                            strokeWidth = 1.2f,
                        )
                    }
                }
        }
        BackgroundStyle.OBSIDIAN_DARK -> {
            Modifier.background(
                Brush.radialGradient(
                    colors = listOf(
                        profile.accentColor.copy(alpha = 0.16f),
                        ObsidianDark,
                    ),
                ),
            )
        }
        BackgroundStyle.SOLAR_GRADIENT -> {
            Modifier.background(
                Brush.verticalGradient(
                    colors = listOf(SolarTop, SolarMid, SolarBottom),
                ),
            )
        }
        BackgroundStyle.SAGE_MIST -> {
            Modifier.background(
                Brush.verticalGradient(
                    colors = listOf(SageTop, SageBottom),
                ),
            )
        }
        BackgroundStyle.CUSTOM_SOLID -> {
            Modifier.background(profile.customBackgroundColor)
        }
    }

    Box(
        modifier = modifier.then(bgModifier),
        content = content,
    )
}

@Composable
fun LauncherClockWidget(
    profile: LauncherProfile,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
) {
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val textColor = if (profile.usesLightForegroundText) SnowWhite else InkBlack
    val mutedColor = if (profile.usesLightForegroundText) SnowWhite.copy(alpha = 0.72f) else InkMuted
    val date = remember(nowMillis / 60_000L) { Date(nowMillis) }
    val timeText = remember(nowMillis / 1000L) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(nowMillis))
    }
    val dateText = remember(nowMillis / 60_000L) {
        SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(date)
    }

    when (profile.clockStyle) {
        ClockStyle.DIGITAL -> {
            Column(
                modifier = modifier,
                horizontalAlignment = Alignment.Start,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = timeText,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (compact) 28.sp else 54.sp,
                        color = textColor,
                        letterSpacing = (-1).sp,
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(if (compact) 6.dp else 10.dp)
                            .clip(CircleShape)
                            .background(profile.accentColor),
                    )
                }
                Text(
                    text = dateText.uppercase(Locale.getDefault()),
                    fontFamily = SpaceGroteskFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = if (compact) 9.sp else 12.sp,
                    letterSpacing = 1.4.sp,
                    color = mutedColor,
                )
            }
        }

        ClockStyle.MINIMAL_SERIF -> {
            Column(
                modifier = modifier,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = timeText,
                    fontFamily = PlayfairDisplayFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = if (compact) 30.sp else 58.sp,
                    color = textColor,
                    letterSpacing = (-0.5).sp,
                )
                Text(
                    text = dateText,
                    fontFamily = PlayfairDisplayFontFamily,
                    fontStyle = FontStyle.Italic,
                    fontSize = if (compact) 10.sp else 15.sp,
                    color = profile.accentColor,
                )
            }
        }

        ClockStyle.ANALOG -> {
            val calendar = remember(nowMillis) {
                Calendar.getInstance().apply { timeInMillis = nowMillis }
            }
            val hours = calendar.get(Calendar.HOUR)
            val minutes = calendar.get(Calendar.MINUTE)
            val seconds = calendar.get(Calendar.SECOND)
            val dialSize = if (compact) 46.dp else 88.dp

            Row(
                modifier = modifier,
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(if (compact) 10.dp else 16.dp),
            ) {
                Canvas(modifier = Modifier.size(dialSize)) {
                    val radius = size.minDimension / 2f
                    val center = Offset(size.width / 2f, size.height / 2f)

                    drawCircle(
                        color = textColor.copy(alpha = 0.28f),
                        radius = radius - 2f,
                        center = center,
                        style = Stroke(width = if (compact) 1.5f else 2.5f),
                    )
                    // 4 cardinal ticks
                    for (tick in 0 until 12) {
                        val angle = (tick * 30.0 - 90.0) * PI / 180.0
                        val outerR = radius - 4f
                        val innerR = if (tick % 3 == 0) radius - (radius * 0.22f) else radius - (radius * 0.12f)
                        drawLine(
                            color = textColor.copy(alpha = if (tick % 3 == 0) 0.7f else 0.35f),
                            start = Offset(
                                center.x + (innerR * cos(angle)).toFloat(),
                                center.y + (innerR * sin(angle)).toFloat(),
                            ),
                            end = Offset(
                                center.x + (outerR * cos(angle)).toFloat(),
                                center.y + (outerR * sin(angle)).toFloat(),
                            ),
                            strokeWidth = if (compact) 1f else 1.8f,
                            cap = StrokeCap.Round,
                        )
                    }
                    // Hour hand
                    val hourAngle = ((hours + minutes / 60f) * 30f - 90f) * PI / 180.0
                    drawLine(
                        color = textColor,
                        start = center,
                        end = Offset(
                            center.x + (radius * 0.50f * cos(hourAngle)).toFloat(),
                            center.y + (radius * 0.50f * sin(hourAngle)).toFloat(),
                        ),
                        strokeWidth = if (compact) 2.2f else 4f,
                        cap = StrokeCap.Round,
                    )
                    // Minute hand
                    val minAngle = ((minutes + seconds / 60f) * 6f - 90f) * PI / 180.0
                    drawLine(
                        color = textColor,
                        start = center,
                        end = Offset(
                            center.x + (radius * 0.72f * cos(minAngle)).toFloat(),
                            center.y + (radius * 0.72f * sin(minAngle)).toFloat(),
                        ),
                        strokeWidth = if (compact) 1.6f else 3f,
                        cap = StrokeCap.Round,
                    )
                    // Second hand
                    val secAngle = (seconds * 6f - 90f) * PI / 180.0
                    drawLine(
                        color = profile.accentColor,
                        start = center,
                        end = Offset(
                            center.x + (radius * 0.80f * cos(secAngle)).toFloat(),
                            center.y + (radius * 0.80f * sin(secAngle)).toFloat(),
                        ),
                        strokeWidth = if (compact) 1f else 1.8f,
                        cap = StrokeCap.Round,
                    )
                    drawCircle(color = profile.accentColor, radius = if (compact) 2f else 3.5f, center = center)
                }

                Column {
                    Text(
                        text = SimpleDateFormat("EEEE", Locale.getDefault()).format(date),
                        fontFamily = SpaceGroteskFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (compact) 12.sp else 20.sp,
                        color = textColor,
                    )
                    Text(
                        text = SimpleDateFormat("MMMM d", Locale.getDefault()).format(date),
                        fontFamily = PlusJakartaSansFontFamily,
                        fontSize = if (compact) 9.sp else 13.sp,
                        color = mutedColor,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIconTile(
    app: InstalledApp,
    profile: LauncherProfile,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconSizeOverride: Dp? = null,
    showLabelOverride: Boolean? = null,
) {
    val iconSize = iconSizeOverride ?: profile.iconSizeDp.dp
    val showLabel = showLabelOverride ?: profile.showLabels
    val shape = profile.iconShape.toComposeShape()
    val tintColor = profile.iconTintColor
    val labelColor = if (profile.usesLightForegroundText) SnowWhite else InkBlack

    Column(
        modifier = modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick,
            )
            .padding(vertical = 4.dp, horizontal = 2.dp)
            .testTag("app_tile_${app.packageName}"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        val tintBg = tintColor?.copy(alpha = profile.iconTintOpacity.coerceIn(0.1f, 0.95f))
            ?: Color.Transparent
        Box(
            modifier = Modifier
                .size(iconSize)
                .clip(shape)
                .background(tintBg),
            contentAlignment = Alignment.Center,
        ) {
            if (app.icon != null) {
                val colorFilter = if (tintColor != null && profile.iconTintOpacity > 0.7f) {
                    ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0.35f) })
                } else {
                    null
                }
                Image(
                    bitmap = app.icon,
                    contentDescription = app.label,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(if (tintColor != null) 6.dp else 0.dp)
                        .clip(shape),
                    contentScale = ContentScale.Crop,
                    colorFilter = colorFilter,
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.Apps,
                    contentDescription = app.label,
                    tint = profile.accentColor,
                    modifier = Modifier.size(iconSize * 0.55f),
                )
            }
        }

        if (showLabel) {
            Spacer(modifier = Modifier.height(5.dp))
            Text(
                text = app.label,
                fontFamily = PlusJakartaSansFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp,
                lineHeight = 13.sp,
                color = labelColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
fun AppActionsDialog(
    app: InstalledApp,
    isPinnedHome: Boolean,
    isPinnedDock: Boolean,
    isHidden: Boolean,
    onLaunch: () -> Unit,
    onToggleHomePin: () -> Unit,
    onToggleDockPin: () -> Unit,
    onToggleHide: () -> Unit,
    onAppInfo: () -> Unit,
    onUninstall: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (app.icon != null) {
                    Image(
                        bitmap = app.icon,
                        contentDescription = app.label,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp)),
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                }
                Column {
                    Text(
                        text = app.label,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = app.packageName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ActionMenuItem(
                    icon = Icons.AutoMirrored.Rounded.OpenInNew,
                    label = "Open ${app.label}",
                    onClick = onLaunch,
                )
                ActionMenuItem(
                    icon = Icons.Outlined.PushPin,
                    label = if (isPinnedHome) "Unpin from Home" else "Pin to Home",
                    onClick = onToggleHomePin,
                )
                ActionMenuItem(
                    icon = Icons.Rounded.Dock,
                    label = if (isPinnedDock) "Unpin from Dock" else "Pin to Dock",
                    onClick = onToggleDockPin,
                )
                ActionMenuItem(
                    icon = if (isHidden) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                    label = if (isHidden) "Show in App Drawer" else "Hide from App Drawer",
                    onClick = onToggleHide,
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                ActionMenuItem(
                    icon = Icons.Outlined.Info,
                    label = "App Info",
                    onClick = onAppInfo,
                )
                if (!app.isSystemApp) {
                    ActionMenuItem(
                        icon = Icons.Outlined.DeleteOutline,
                        label = "Uninstall",
                        tint = MaterialTheme.colorScheme.error,
                        onClick = onUninstall,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        },
    )
}

@Composable
private fun ActionMenuItem(
    icon: ImageVector,
    label: String,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = Color.Transparent,
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 48.dp),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = tint,
            )
        }
    }
}
