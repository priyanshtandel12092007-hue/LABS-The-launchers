package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.InkBlack
import com.example.ui.theme.InkMuted
import com.example.ui.theme.PaperWarm
import com.example.ui.theme.PaperWarmBorder
import com.example.ui.theme.PlayfairDisplayFontFamily
import com.example.ui.theme.SpaceGroteskFontFamily

/**
 * LABS emblem badge displaying the bundled labs_logo artwork matching the launcher icon.
 */
@Composable
fun LabsEmblemBadge(
    modifier: Modifier = Modifier,
    size: Dp = 68.dp,
) {
    Surface(
        modifier = modifier.size(size),
        shape = RoundedCornerShape(18.dp),
        color = PaperWarm,
        border = BorderStroke(1.dp, PaperWarmBorder),
        shadowElevation = 2.dp,
    ) {
        Image(
            painter = painterResource(id = R.drawable.labs_logo),
            contentDescription = "LABS The launchers logo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
    }
}

/**
 * Editorial splash/header logo card displayed inside Launcher Studio.
 */
@Composable
fun LabsStudioHeaderBanner(
    accentColor: Color,
    isDefaultLauncher: Boolean,
    onSetDefaultClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = PaperWarm,
        border = BorderStroke(1.dp, PaperWarmBorder),
        shadowElevation = 1.dp,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                LabsEmblemBadge(size = 62.dp)
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = "LABS",
                        fontFamily = SpaceGroteskFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        letterSpacing = 2.sp,
                        color = InkBlack,
                    )
                    Text(
                        text = "The launchers",
                        fontFamily = PlayfairDisplayFontFamily,
                        fontStyle = FontStyle.Italic,
                        fontSize = 15.sp,
                        color = InkMuted,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "STUDIO & THEME CREATOR",
                        fontFamily = SpaceGroteskFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 10.sp,
                        letterSpacing = 1.1.sp,
                        color = accentColor,
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Surface(
                onClick = onSetDefaultClick,
                shape = RoundedCornerShape(50),
                color = if (isDefaultLauncher) Color(0xFF1F7A4C).copy(alpha = 0.14f) else accentColor,
                border = if (isDefaultLauncher) BorderStroke(1.dp, Color(0xFF1F7A4C)) else null,
            ) {
                Text(
                    text = if (isDefaultLauncher) "Default Active" else "Set Default",
                    fontFamily = SpaceGroteskFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = if (isDefaultLauncher) Color(0xFF155E39) else Color.White,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                )
            }
        }
    }
}
