package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// LABS Core Editorial Palette
val PaperWarm = Color(0xFFEAE6DF)
val PaperWarmElevated = Color(0xFFF3F0EA)
val PaperWarmBorder = Color(0xFFD5CFC4)
val InkBlack = Color(0xFF151412)
val InkMuted = Color(0xFF5C5852)

val ObsidianDark = Color(0xFF111317)
val ObsidianSurface = Color(0xFF1B1E24)
val ObsidianSurfaceHigh = Color(0xFF252932)
val SnowWhite = Color(0xFFF6F5F2)
val SlateMuted = Color(0xFF9DA3AE)

// Studio Accent Colors
val AccentTerracotta = Color(0xFFD94E28)
val AccentCobalt = Color(0xFF2563EB)
val AccentAmber = Color(0xFFF59E0B)
val AccentEmerald = Color(0xFF10B981)
val AccentRose = Color(0xFFE11D48)
val AccentInk = Color(0xFF18181B)

// Gradient & Atmosphere Tokens
val SolarTop = Color(0xFF2B1B3D)
val SolarMid = Color(0xFF7B334D)
val SolarBottom = Color(0xFFD96F32)

val SageTop = Color(0xFFDCE3DC)
val SageBottom = Color(0xFFBAC7BC)
