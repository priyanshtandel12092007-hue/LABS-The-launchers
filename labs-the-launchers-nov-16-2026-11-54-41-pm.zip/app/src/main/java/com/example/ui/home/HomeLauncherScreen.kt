package com.example.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BackgroundStyle
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherProfile
import com.example.data.model.StudioPalettes
import com.example.ui.LauncherUiState
import com.example.ui.components.AppActionsDialog
import com.example.ui.components.AppIconTile
import com.example.ui.components.LauncherBackgroundSurface
import com.example.ui.components.LauncherClockWidget
import com.example.ui.drawer.AppDrawerOverlay
import com.example.ui.theme.InkBlack
import com.example.ui.theme.InkMuted
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.PlusJakartaSansFontFamily
import com.example.ui.theme.SnowWhite
import com.example.ui.theme.SpaceGroteskFontFamily

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeLauncherScreen(
    state: LauncherUiState,
    onOpenStudio: () -> Unit,
    onOpenDrawer: (Boolean) -> Unit,
    onCloseDrawer: () -> Unit,
    onDrawerSearchChange: (String) -> Unit,
    onToggleShowHidden: () -> Unit,
    onLaunchApp: (InstalledApp) -> Unit,
    onAppLongClick: (InstalledApp) -> Unit,
    onDismissAppActions: () -> Unit,
    onPinHome: (String) -> Unit,
    onPinDock: (String) -> Unit,
    onUnpinApp: (String) -> Unit,
    onHideApp: (String) -> Unit,
    onUnhideApp: (String) -> Unit,
    onOpenAppInfo: (String) -> Unit,
    onUninstallApp: (String) -> Unit,
    onOpenQuickMenu: () -> Unit,
    onCloseQuickMenu: () -> Unit,
    onOpenWallpaperSheet: () -> Unit,
    onCloseWallpaperSheet: () -> Unit,
    onQuickSelectBackground: (BackgroundStyle, Long?) -> Unit,
    onOpenSystemWallpaperPicker: () -> Unit,
    onSetDefaultLauncher: () -> Unit,
    onDismissDefaultBanner: () -> Unit,
    onOpenSystemSettings: () -> Unit,
) {
    val profile = state.activeProfile
    val isLightBg = !profile.usesLightForegroundText
    val fgColor = if (isLightBg) InkBlack else SnowWhite
    val mutedColor = if (isLightBg) InkMuted else SnowWhite.copy(alpha = 0.7f)
    val glassBg = if (isLightBg) Color.Black.copy(alpha = 0.06f) else Color.White.copy(alpha = 0.12f)
    val glassBorder = if (isLightBg) Color.Black.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.18f)

    val statusPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    var verticalSwipeDelta by remember { mutableFloatStateOf(0f) }

    LauncherBackgroundSurface(
        profile = profile,
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { verticalSwipeDelta = 0f },
                    onVerticalDrag = { _, dragAmount ->
                        verticalSwipeDelta += dragAmount
                        if (verticalSwipeDelta < -72f) {
                            verticalSwipeDelta = 0f
                            onOpenDrawer(false)
                        }
                    },
                    onDragEnd = { verticalSwipeDelta = 0f },
                    onDragCancel = { verticalSwipeDelta = 0f },
                )
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onLongPress = { onOpenQuickMenu() },
                )
            },
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .align(Alignment.Center)
                .padding(
                    top = statusPadding + 10.dp,
                    bottom = navPadding + 10.dp,
                    start = 18.dp,
                    end = 18.dp,
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Top Controls Row: Default Launcher CTA + Studio Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (!state.isDefaultLauncher && !state.isDefaultBannerDismissed) {
                    Surface(
                        onClick = onSetDefaultLauncher,
                        shape = RoundedCornerShape(50),
                        color = profile.accentColor,
                        shadowElevation = 2.dp,
                        modifier = Modifier.testTag("set_default_launcher_button"),
                    ) {
                        Row(
                            modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Home,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Set as Default Launcher",
                                fontFamily = SpaceGroteskFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp,
                                color = Color.White,
                            )
                            IconButton(
                                onClick = onDismissDefaultBanner,
                                modifier = Modifier.size(26.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Dismiss default launcher prompt",
                                    tint = Color.White.copy(alpha = 0.85f),
                                    modifier = Modifier.size(14.dp),
                                )
                            }
                        }
                    }
                } else {
                    Text(
                        text = profile.name.uppercase(),
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        letterSpacing = 1.2.sp,
                        color = mutedColor,
                    )
                }

                Surface(
                    onClick = onOpenStudio,
                    shape = RoundedCornerShape(50),
                    color = glassBg,
                    border = BorderStroke(1.dp, glassBorder),
                    modifier = Modifier
                        .defaultMinSize(minHeight = 36.dp)
                        .testTag("open_studio_button"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.RocketLaunch,
                            contentDescription = "Launcher Studio",
                            tint = profile.accentColor,
                            modifier = Modifier.size(15.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Studio",
                            fontFamily = SpaceGroteskFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = fgColor,
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Customizable Top Clock & Date Widget
            LauncherClockWidget(
                profile = profile,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Mode A Main Area: Icon Grid OR Minimalist Text-List Launcher
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) {
                val displayApps = remember(state.homeGridApps, state.installedApps, profile.gridColumns, profile.gridRows) {
                    val maxSlots = profile.gridColumns * profile.gridRows
                    val source = state.homeGridApps.ifEmpty {
                        state.installedApps.filter { it.packageName !in state.hiddenPackages }
                    }
                    source.take(maxSlots)
                }

                if (profile.minimalistMode) {
                    MinimalistTextLauncherList(
                        apps = displayApps,
                        profile = profile,
                        fgColor = fgColor,
                        mutedColor = mutedColor,
                        onAppClick = onLaunchApp,
                        onAppLongClick = onAppLongClick,
                    )
                } else {
                    HomeAppGrid(
                        apps = displayApps,
                        profile = profile,
                        onAppClick = onLaunchApp,
                        onAppLongClick = onAppLongClick,
                    )
                }
            }

            // Optional Search Bar Pill
            if (profile.showSearchBar) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    onClick = { onOpenDrawer(true) },
                    shape = RoundedCornerShape(50),
                    color = glassBg,
                    border = BorderStroke(1.dp, glassBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .testTag("home_search_bar"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Search apps",
                            tint = profile.accentColor,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Search apps or swipe up…",
                            fontFamily = PlusJakartaSansFontFamily,
                            fontSize = 14.sp,
                            color = mutedColor,
                            modifier = Modifier.weight(1f),
                        )
                        Icon(
                            imageVector = Icons.Rounded.KeyboardArrowUp,
                            contentDescription = "Open app drawer",
                            tint = mutedColor,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            } else {
                // Subtle swipe up indicator
                Row(
                    modifier = Modifier
                        .clickable { onOpenDrawer(false) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowUp,
                        contentDescription = "Swipe up for apps",
                        tint = mutedColor,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "SWIPE UP FOR APPS",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 10.sp,
                        letterSpacing = 1.1.sp,
                        color = mutedColor,
                    )
                }
            }

            // Bottom Favorite Dock
            if (profile.showDock && state.dockApps.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = glassBg,
                    border = BorderStroke(1.dp, glassBorder),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        state.dockApps.take(5).forEach { app ->
                            AppIconTile(
                                app = app,
                                profile = profile,
                                onClick = { onLaunchApp(app) },
                                onLongClick = { onAppLongClick(app) },
                                iconSizeOverride = profile.iconSizeDp.coerceAtMost(54f).dp,
                                showLabelOverride = false,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
            }
        }

        // Slide-up Searchable App Drawer
        AnimatedVisibility(
            visible = state.isDrawerOpen,
            enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
        ) {
            AppDrawerOverlay(
                apps = state.installedApps,
                hiddenPackages = state.hiddenPackages,
                pinnedHomePackages = state.pinnedHomePackages,
                pinnedDockPackages = state.pinnedDockPackages,
                profile = profile,
                searchQuery = state.drawerSearchQuery,
                focusSearchOnOpen = state.focusDrawerSearch,
                showHiddenApps = state.showHiddenInDrawer,
                onSearchChange = onDrawerSearchChange,
                onToggleShowHidden = onToggleShowHidden,
                onAppClick = onLaunchApp,
                onAppLongClick = onAppLongClick,
                onClose = onCloseDrawer,
            )
        }

        // Long-press Empty Home Screen Quick Menu
        if (state.showHomeQuickMenu) {
            HomeQuickMenuDialog(
                isDefaultLauncher = state.isDefaultLauncher,
                accentColor = profile.accentColor,
                onOpenStudio = onOpenStudio,
                onOpenWallpapers = onOpenWallpaperSheet,
                onSetDefaultLauncher = onSetDefaultLauncher,
                onOpenSystemSettings = onOpenSystemSettings,
                onDismiss = onCloseQuickMenu,
            )
        }

        // Long-press App Icon Action Dialog
        state.selectedAppForActions?.let { app ->
            val isPinnedHome = app.packageName in state.pinnedHomePackages
            val isPinnedDock = app.packageName in state.pinnedDockPackages
            val isHidden = app.packageName in state.hiddenPackages
            AppActionsDialog(
                app = app,
                isPinnedHome = isPinnedHome,
                isPinnedDock = isPinnedDock,
                isHidden = isHidden,
                onLaunch = { onLaunchApp(app) },
                onToggleHomePin = {
                    if (isPinnedHome) onUnpinApp(app.packageName) else onPinHome(app.packageName)
                },
                onToggleDockPin = {
                    if (isPinnedDock) onUnpinApp(app.packageName) else onPinDock(app.packageName)
                },
                onToggleHide = {
                    if (isHidden) onUnhideApp(app.packageName) else onHideApp(app.packageName)
                },
                onAppInfo = { onOpenAppInfo(app.packageName) },
                onUninstall = { onUninstallApp(app.packageName) },
                onDismiss = onDismissAppActions,
            )
        }

        // Quick Wallpaper & Background Picker Sheet
        if (state.showWallpaperSheet) {
            ModalBottomSheet(onDismissRequest = onCloseWallpaperSheet) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .padding(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        text = "Wallpapers & Backdrop",
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        text = "Choose LABS custom backgrounds or show your live Android system wallpaper.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        BackgroundStyle.entries.filter { it != BackgroundStyle.CUSTOM_SOLID }.take(3).forEach { bg ->
                            val selected = profile.backgroundStyle == bg
                            Surface(
                                onClick = { onQuickSelectBackground(bg, null) },
                                shape = RoundedCornerShape(14.dp),
                                color = if (selected) profile.accentColor.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (selected) BorderStroke(1.5.dp, profile.accentColor) else null,
                                modifier = Modifier.weight(1f),
                            ) {
                                Text(
                                    text = bg.displayName,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                                )
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        BackgroundStyle.entries.filter { it != BackgroundStyle.CUSTOM_SOLID }.drop(3).forEach { bg ->
                            val selected = profile.backgroundStyle == bg
                            Surface(
                                onClick = { onQuickSelectBackground(bg, null) },
                                shape = RoundedCornerShape(14.dp),
                                color = if (selected) profile.accentColor.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (selected) BorderStroke(1.5.dp, profile.accentColor) else null,
                                modifier = Modifier.weight(1f),
                            ) {
                                Text(
                                    text = bg.displayName,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                                )
                            }
                        }
                        Surface(
                            onClick = {
                                onQuickSelectBackground(
                                    BackgroundStyle.CUSTOM_SOLID,
                                    StudioPalettes.solidBackgroundSwatches.first().second,
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            color = if (profile.backgroundStyle == BackgroundStyle.CUSTOM_SOLID) {
                                profile.accentColor.copy(alpha = 0.16f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(
                                text = "Custom Solid",
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        OutlinedButton(
                            onClick = onOpenSystemWallpaperPicker,
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Outlined.Wallpaper, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("System Picker")
                        }
                        Button(
                            onClick = {
                                onCloseWallpaperSheet()
                                onOpenStudio()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = profile.accentColor),
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Full Studio")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeAppGrid(
    apps: List<InstalledApp>,
    profile: LauncherProfile,
    onAppClick: (InstalledApp) -> Unit,
    onAppLongClick: (InstalledApp) -> Unit,
) {
    val cols = profile.gridColumns.coerceIn(3, 6)
    val rows = profile.gridRows.coerceIn(3, 7)

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val cellHeight = (maxHeight / rows).coerceAtLeast(62.dp)
        val adaptiveIconSize = minOf(profile.iconSizeDp.dp, (cellHeight - 20.dp).coerceAtLeast(36.dp))

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Top,
        ) {
            for (r in 0 until rows) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(cellHeight),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    for (c in 0 until cols) {
                        val index = r * cols + c
                        val app = apps.getOrNull(index)
                        if (app != null) {
                            AppIconTile(
                                app = app,
                                profile = profile,
                                onClick = { onAppClick(app) },
                                onLongClick = { onAppLongClick(app) },
                                iconSizeOverride = adaptiveIconSize,
                                modifier = Modifier.weight(1f),
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MinimalistTextLauncherList(
    apps: List<InstalledApp>,
    profile: LauncherProfile,
    fgColor: Color,
    mutedColor: Color,
    onAppClick: (InstalledApp) -> Unit,
    onAppLongClick: (InstalledApp) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        itemsIndexed(apps, key = { _, app -> "${app.packageName}_${app.activityName}" }) { index, app ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .combinedClickable(
                        onClick = { onAppClick(app) },
                        onLongClick = { onAppLongClick(app) },
                    )
                    .padding(horizontal = 8.dp, vertical = 10.dp)
                    .testTag("minimal_app_${app.packageName}"),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = String.format("%02d", index + 1),
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 12.sp,
                    color = profile.accentColor,
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = app.label,
                    fontFamily = SpaceGroteskFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize = 22.sp,
                    color = fgColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(mutedColor.copy(alpha = 0.28f)),
                )
            }
        }
    }
}

@Composable
private fun HomeQuickMenuDialog(
    isDefaultLauncher: Boolean,
    accentColor: Color,
    onOpenStudio: () -> Unit,
    onOpenWallpapers: () -> Unit,
    onSetDefaultLauncher: () -> Unit,
    onOpenSystemSettings: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "LABS Home Menu",
                fontFamily = SpaceGroteskFontFamily,
                fontWeight = FontWeight.Bold,
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                QuickMenuButton(
                    icon = Icons.Outlined.Palette,
                    title = "Launcher Studio",
                    subtitle = "Customize grids, icons, clocks & presets",
                    accentColor = accentColor,
                    onClick = onOpenStudio,
                )
                QuickMenuButton(
                    icon = Icons.Outlined.Wallpaper,
                    title = "Wallpapers",
                    subtitle = "Live system wallpaper or LABS backdrops",
                    accentColor = accentColor,
                    onClick = onOpenWallpapers,
                )
                QuickMenuButton(
                    icon = Icons.Outlined.Home,
                    title = if (isDefaultLauncher) "Default Launcher Settings" else "Set as Default Launcher",
                    subtitle = if (isDefaultLauncher) "LABS is active" else "Open Android Home app chooser",
                    accentColor = accentColor,
                    onClick = onSetDefaultLauncher,
                )
                QuickMenuButton(
                    icon = Icons.Outlined.Settings,
                    title = "System Settings",
                    subtitle = "Open Android device settings",
                    accentColor = accentColor,
                    onClick = onOpenSystemSettings,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Dismiss")
            }
        },
    )
}

@Composable
private fun QuickMenuButton(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accentColor: Color,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 52.dp),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = accentColor,
                modifier = Modifier.size(22.dp),
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontSize = 14.sp,
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
