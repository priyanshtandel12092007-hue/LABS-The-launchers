package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private fun buildLightColorScheme(accent: Color) = lightColorScheme(
    primary = accent,
    onPrimary = Color.White,
    primaryContainer = accent.copy(alpha = 0.14f),
    onPrimaryContainer = InkBlack,
    secondary = InkBlack,
    onSecondary = PaperWarm,
    secondaryContainer = PaperWarmElevated,
    onSecondaryContainer = InkBlack,
    background = PaperWarm,
    onBackground = InkBlack,
    surface = PaperWarmElevated,
    onSurface = InkBlack,
    surfaceVariant = Color(0xFFE1DCD3),
    onSurfaceVariant = InkMuted,
    outline = PaperWarmBorder,
)

private fun buildDarkColorScheme(accent: Color) = darkColorScheme(
    primary = accent,
    onPrimary = Color.White,
    primaryContainer = accent.copy(alpha = 0.22f),
    onPrimaryContainer = SnowWhite,
    secondary = SnowWhite,
    onSecondary = ObsidianDark,
    secondaryContainer = ObsidianSurfaceHigh,
    onSecondaryContainer = SnowWhite,
    background = ObsidianDark,
    onBackground = SnowWhite,
    surface = ObsidianSurface,
    onSurface = SnowWhite,
    surfaceVariant = ObsidianSurfaceHigh,
    onSurfaceVariant = SlateMuted,
    outline = Color(0xFF343A46),
)

@Composable
fun LabsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    accentColor: Color = AccentTerracotta,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) {
        buildDarkColorScheme(accentColor)
    } else {
        buildLightColorScheme(accentColor)
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = LabsTypography,
        content = content,
    )
}
