package com.example.ui.studio

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Wallpaper
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BackgroundStyle
import com.example.data.model.ClockStyle
import com.example.data.model.IconShape
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherProfile
import com.example.data.model.StudioPalettes
import com.example.ui.LauncherUiState
import com.example.ui.components.AppIconTile
import com.example.ui.components.LabsStudioHeaderBanner
import com.example.ui.components.LauncherBackgroundSurface
import com.example.ui.components.LauncherClockWidget
import com.example.ui.components.toComposeShape
import com.example.ui.theme.InkBlack
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SnowWhite
import com.example.ui.theme.SpaceGroteskFontFamily

private val STUDIO_TABS = listOf("Presets", "Layout", "Style", "Backdrop")

@Composable
fun LauncherStudioScreen(
    state: LauncherUiState,
    onUpdateDraft: ((LauncherProfile) -> LauncherProfile) -> Unit,
    onSelectProfile: (LauncherProfile) -> Unit,
    onApplyToHome: () -> Unit,
    onSaveAsNewProfile: (String) -> Unit,
    onDeleteProfile: (String) -> Unit,
    onSetDefaultLauncher: () -> Unit,
    onOpenSystemWallpaperPicker: () -> Unit,
    onBackToHome: () -> Unit,
) {
    BackHandler(onBack = onBackToHome)

    val draft = state.studioDraftProfile
    var selectedTab by remember { mutableIntStateOf(0) }
    var showSaveDialog by remember { mutableStateOf(false) }

    val statusPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Surface(
                tonalElevation = 4.dp,
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            start = 16.dp,
                            end = 16.dp,
                            top = 12.dp,
                            bottom = navPadding + 12.dp,
                        ),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedButton(
                        onClick = { showSaveDialog = true },
                        modifier = Modifier
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("studio_save_as_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.BookmarkAdd,
                            contentDescription = "Save as new profile",
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save As")
                    }

                    Button(
                        onClick = onApplyToHome,
                        colors = ButtonDefaults.buttonColors(containerColor = draft.accentColor),
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("studio_apply_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.RocketLaunch,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Apply to Home",
                            fontFamily = SpaceGroteskFontFamily,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding()),
            contentAlignment = Alignment.TopCenter,
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 680.dp),
                contentPadding = PaddingValues(
                    top = statusPadding + 10.dp,
                    start = 16.dp,
                    end = 16.dp,
                    bottom = 24.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                // Top Back Bar
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onBackToHome,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("studio_back_home_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                    contentDescription = "Return to Home Launcher",
                                )
                            }
                            Text(
                                text = "Active: ${draft.name}",
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Text(
                            text = if (draft.minimalistMode) "TEXT LIST" else "${draft.gridColumns}×${draft.gridRows} GRID",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = draft.accentColor,
                        )
                    }
                }

                // Matching Splash / Header Logo Banner
                item {
                    LabsStudioHeaderBanner(
                        accentColor = draft.accentColor,
                        isDefaultLauncher = state.isDefaultLauncher,
                        onSetDefaultClick = onSetDefaultLauncher,
                    )
                }

                // Live Interactive Preview
                item {
                    LiveLauncherPreviewCard(
                        profile = draft,
                        sampleApps = state.homeGridApps.ifEmpty { state.installedApps },
                    )
                }

                // Section Tabs
                item {
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = draft.accentColor,
                        modifier = Modifier.clip(RoundedCornerShape(16.dp)),
                    ) {
                        STUDIO_TABS.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                text = {
                                    Text(
                                        text = title,
                                        fontFamily = SpaceGroteskFontFamily,
                                        fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 13.sp,
                                    )
                                },
                                modifier = Modifier.testTag("studio_tab_${title.lowercase()}"),
                            )
                        }
                    }
                }

                // Active Tab Content
                when (selectedTab) {
                    0 -> item {
                        PresetsSection(
                            profiles = state.savedProfiles,
                            activeDraftId = draft.id,
                            onSelectProfile = onSelectProfile,
                            onDeleteProfile = onDeleteProfile,
                        )
                    }
                    1 -> item {
                        LayoutSection(
                            draft = draft,
                            onUpdateDraft = onUpdateDraft,
                        )
                    }
                    2 -> item {
                        StyleSection(
                            draft = draft,
                            onUpdateDraft = onUpdateDraft,
                        )
                    }
                    3 -> item {
                        BackdropSection(
                            draft = draft,
                            onUpdateDraft = onUpdateDraft,
                            onOpenSystemWallpaperPicker = onOpenSystemWallpaperPicker,
                        )
                    }
                }
            }
        }
    }

    if (showSaveDialog) {
        SaveProfileDialog(
            initialName = if (draft.isPreset) "${draft.name} Mix" else draft.name,
            accentColor = draft.accentColor,
            onSave = { name ->
                showSaveDialog = false
                onSaveAsNewProfile(name)
            },
            onDismiss = { showSaveDialog = false },
        )
    }
}

@Composable
private fun LiveLauncherPreviewCard(
    profile: LauncherProfile,
    sampleApps: List<InstalledApp>,
) {
    val previewApps = remember(sampleApps, profile.gridColumns, profile.gridRows) {
        sampleApps.take((profile.gridColumns * 2).coerceAtMost(10))
    }
    val fgColor = if (profile.usesLightForegroundText) SnowWhite else InkBlack

    Surface(
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        LauncherBackgroundSurface(
            profile = profile,
            modifier = Modifier
                .fillMaxWidth()
                .height(248.dp)
                .padding(16.dp),
        ) {
            if (profile.backgroundStyle == BackgroundStyle.SYSTEM_WALLPAPER) {
                Text(
                    text = "LIVE WALLPAPER",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 9.sp,
                    color = SnowWhite.copy(alpha = 0.65f),
                    modifier = Modifier.align(Alignment.TopEnd),
                )
            }
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                LauncherClockWidget(profile = profile, compact = true)

                if (profile.minimalistMode) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        val names = previewApps.take(4).map { it.label }
                            .ifEmpty { listOf("Camera", "Messages", "Browser", "Music") }
                        names.forEachIndexed { idx, label ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "0${idx + 1}",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 10.sp,
                                    color = profile.accentColor,
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = label,
                                    fontFamily = SpaceGroteskFontFamily,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = fgColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                    ) {
                        val cols = profile.gridColumns.coerceIn(4, 5)
                        for (i in 0 until cols) {
                            val app = previewApps.getOrNull(i)
                            if (app != null) {
                                AppIconTile(
                                    app = app,
                                    profile = profile,
                                    onClick = {},
                                    onLongClick = {},
                                    iconSizeOverride = (profile.iconSizeDp * 0.62f).dp,
                                    modifier = Modifier.weight(1f),
                                )
                            } else {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size((profile.iconSizeDp * 0.62f).dp)
                                            .clip(profile.iconShape.toComposeShape())
                                            .background(
                                                (profile.iconTintColor ?: profile.accentColor)
                                                    .copy(alpha = 0.25f),
                                            ),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Apps,
                                            contentDescription = null,
                                            tint = fgColor,
                                            modifier = Modifier.size(18.dp),
                                        )
                                    }
                                    if (profile.showLabels) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "App ${i + 1}",
                                            fontSize = 9.sp,
                                            color = fgColor,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Mini Dock Preview
                if (profile.showDock) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = fgColor.copy(alpha = 0.10f),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                        ) {
                            repeat(4) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(profile.iconShape.toComposeShape())
                                        .background(profile.accentColor.copy(alpha = 0.78f)),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PresetsSection(
    profiles: List<LauncherProfile>,
    activeDraftId: String,
    onSelectProfile: (LauncherProfile) -> Unit,
    onDeleteProfile: (String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "Starter Presets & Saved Launchers",
            style = MaterialTheme.typography.titleMedium,
        )
        profiles.forEach { item ->
            val selected = item.id == activeDraftId
            Surface(
                onClick = { onSelectProfile(item) },
                shape = RoundedCornerShape(18.dp),
                color = if (selected) item.accentColor.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                border = BorderStroke(
                    width = if (selected) 1.5.dp else 1.dp,
                    color = if (selected) item.accentColor else MaterialTheme.colorScheme.outline,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_card_${item.id}"),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(item.iconShape.toComposeShape())
                            .background(item.accentColor),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (selected) {
                            Icon(
                                imageVector = Icons.Rounded.Check,
                                contentDescription = "Selected",
                                tint = Color.White,
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.RocketLaunch,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp),
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.titleMedium,
                            )
                            if (item.isPreset) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                ) {
                                    Text(
                                        text = "PRESET",
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontSize = 9.sp,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                                    )
                                }
                            }
                        }
                        val modeLabel = if (item.minimalistMode) "Text List" else "${item.gridColumns}×${item.gridRows} Grid"
                        Text(
                            text = "$modeLabel · ${item.clockStyle.displayName} · ${item.backgroundStyle.displayName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (!item.isPreset) {
                        IconButton(onClick = { onDeleteProfile(item.id) }) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteOutline,
                                contentDescription = "Delete profile ${item.name}",
                                tint = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LayoutSection(
    draft: LauncherProfile,
    onUpdateDraft: ((LauncherProfile) -> LauncherProfile) -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(text = "Launcher Mode", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = !draft.minimalistMode,
                    onClick = { onUpdateDraft { it.copy(minimalistMode = false) } },
                    label = { Text("Icon Grid") },
                    modifier = Modifier.weight(1f),
                )
                FilterChip(
                    selected = draft.minimalistMode,
                    onClick = { onUpdateDraft { it.copy(minimalistMode = true) } },
                    label = { Text("Minimalist Text List") },
                    modifier = Modifier.weight(1f),
                )
            }

            if (!draft.minimalistMode) {
                Text(text = "Grid Presets", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(4 to 5, 5 to 6, 5 to 7).forEach { (cols, rows) ->
                        val isMatch = draft.gridColumns == cols && draft.gridRows == rows
                        FilterChip(
                            selected = isMatch,
                            onClick = { onUpdateDraft { it.copy(gridColumns = cols, gridRows = rows) } },
                            label = { Text("${cols}×$rows") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = draft.accentColor.copy(alpha = 0.16f),
                            ),
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Columns: ${draft.gridColumns}",
                        style = MaterialTheme.typography.labelLarge,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(4, 5).forEach { cols ->
                            FilterChip(
                                selected = draft.gridColumns == cols,
                                onClick = { onUpdateDraft { it.copy(gridColumns = cols) } },
                                label = { Text("$cols") },
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = "Rows: ${draft.gridRows}",
                        style = MaterialTheme.typography.labelLarge,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(4, 5, 6, 7).forEach { rows ->
                            FilterChip(
                                selected = draft.gridRows == rows,
                                onClick = { onUpdateDraft { it.copy(gridRows = rows) } },
                                label = { Text("$rows") },
                            )
                        }
                    }
                }

                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(text = "Icon Size", style = MaterialTheme.typography.labelLarge)
                        Text(
                            text = "${draft.iconSizeDp.toInt()} dp",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp,
                            color = draft.accentColor,
                        )
                    }
                    Slider(
                        value = draft.iconSizeDp,
                        onValueChange = { size -> onUpdateDraft { it.copy(iconSizeDp = size) } },
                        valueRange = 40f..68f,
                        colors = SliderDefaults.colors(
                            thumbColor = draft.accentColor,
                            activeTrackColor = draft.accentColor,
                        ),
                    )
                }

                StudioToggleRow(
                    label = "Show App Labels",
                    checked = draft.showLabels,
                    accentColor = draft.accentColor,
                    onCheckedChange = { v -> onUpdateDraft { it.copy(showLabels = v) } },
                )
            }

            StudioToggleRow(
                label = "Show Home Search Bar",
                checked = draft.showSearchBar,
                accentColor = draft.accentColor,
                onCheckedChange = { v -> onUpdateDraft { it.copy(showSearchBar = v) } },
            )

            StudioToggleRow(
                label = "Show Favorite Dock",
                checked = draft.showDock,
                accentColor = draft.accentColor,
                onCheckedChange = { v -> onUpdateDraft { it.copy(showDock = v) } },
            )
        }
    }
}

@Composable
private fun StyleSection(
    draft: LauncherProfile,
    onUpdateDraft: ((LauncherProfile) -> LauncherProfile) -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(text = "Icon Corner Shape", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconShape.entries.forEach { shape ->
                    val selected = draft.iconShape == shape
                    Surface(
                        onClick = { onUpdateDraft { it.copy(iconShape = shape) } },
                        shape = RoundedCornerShape(14.dp),
                        color = if (selected) draft.accentColor.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (selected) BorderStroke(1.5.dp, draft.accentColor) else null,
                        modifier = Modifier.weight(1f),
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(shape.toComposeShape())
                                    .background(draft.accentColor),
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = shape.displayName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                    }
                }
            }

            Text(text = "Clock Style", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ClockStyle.entries.forEach { clock ->
                    FilterChip(
                        selected = draft.clockStyle == clock,
                        onClick = { onUpdateDraft { it.copy(clockStyle = clock) } },
                        label = { Text(clock.displayName, fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            Text(text = "Accent Color", style = MaterialTheme.typography.titleMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(StudioPalettes.accentSwatches) { (name, hex) ->
                    val selected = draft.accentColorHex == hex
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(hex))
                                .border(
                                    width = if (selected) 3.dp else 1.dp,
                                    color = if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                    shape = CircleShape,
                                )
                                .clickable { onUpdateDraft { it.copy(accentColorHex = hex) } },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (selected) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = "$name selected",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = name, fontSize = 10.sp)
                    }
                }
            }

            Text(text = "Icon Background Tint", style = MaterialTheme.typography.titleMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(StudioPalettes.iconTintSwatches) { (name, hex) ->
                    val selected = draft.iconTintHex == hex
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(draft.iconShape.toComposeShape())
                                .background(
                                    if (hex == 0L) MaterialTheme.colorScheme.surfaceVariant else Color(hex),
                                )
                                .border(
                                    width = if (selected) 2.5.dp else 1.dp,
                                    color = if (selected) draft.accentColor else MaterialTheme.colorScheme.outline,
                                    shape = draft.iconShape.toComposeShape(),
                                )
                                .clickable { onUpdateDraft { it.copy(iconTintHex = hex) } },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (hex == 0L) {
                                Text("Off", fontSize = 10.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = name, fontSize = 10.sp)
                    }
                }
            }

            if (draft.iconTintHex != 0L) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(text = "Icon Tint Strength", style = MaterialTheme.typography.labelLarge)
                        Text(
                            text = "${(draft.iconTintOpacity * 100).toInt()}%",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp,
                        )
                    }
                    Slider(
                        value = draft.iconTintOpacity,
                        onValueChange = { v -> onUpdateDraft { it.copy(iconTintOpacity = v) } },
                        valueRange = 0.1f..0.95f,
                        colors = SliderDefaults.colors(
                            thumbColor = draft.accentColor,
                            activeTrackColor = draft.accentColor,
                        ),
                    )
                }
            }
        }
    }
}

@Composable
private fun BackdropSection(
    draft: LauncherProfile,
    onUpdateDraft: ((LauncherProfile) -> LauncherProfile) -> Unit,
    onOpenSystemWallpaperPicker: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(text = "Home Screen Background", style = MaterialTheme.typography.titleMedium)

            BackgroundStyle.entries.chunked(2).forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    rowItems.forEach { bg ->
                        val selected = draft.backgroundStyle == bg
                        Surface(
                            onClick = { onUpdateDraft { it.copy(backgroundStyle = bg) } },
                            shape = RoundedCornerShape(14.dp),
                            color = if (selected) draft.accentColor.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (selected) BorderStroke(1.5.dp, draft.accentColor) else null,
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(
                                text = bg.displayName,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
                            )
                        }
                    }
                }
            }

            if (draft.backgroundStyle == BackgroundStyle.SYSTEM_WALLPAPER) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(text = "Wallpaper Dimming Scrim", style = MaterialTheme.typography.labelLarge)
                        Text(
                            text = "${(draft.wallpaperScrimAlpha * 100).toInt()}%",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp,
                        )
                    }
                    Slider(
                        value = draft.wallpaperScrimAlpha,
                        onValueChange = { v -> onUpdateDraft { it.copy(wallpaperScrimAlpha = v) } },
                        valueRange = 0f..0.6f,
                        colors = SliderDefaults.colors(
                            thumbColor = draft.accentColor,
                            activeTrackColor = draft.accentColor,
                        ),
                    )
                }

                OutlinedButton(
                    onClick = onOpenSystemWallpaperPicker,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Outlined.Wallpaper, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Choose Android System Wallpaper")
                }
            }

            if (draft.backgroundStyle == BackgroundStyle.CUSTOM_SOLID) {
                Text(text = "Solid Background Color", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(StudioPalettes.solidBackgroundSwatches) { (name, hex) ->
                        val selected = draft.customBackgroundHex == hex
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Color(hex))
                                    .border(
                                        width = if (selected) 2.5.dp else 1.dp,
                                        color = if (selected) draft.accentColor else MaterialTheme.colorScheme.outline,
                                        shape = CircleShape,
                                    )
                                    .clickable { onUpdateDraft { it.copy(customBackgroundHex = hex) } },
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = name, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioToggleRow(
    label: String,
    checked: Boolean,
    accentColor: Color,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 48.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyLarge)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = androidx.compose.material3.SwitchDefaults.colors(
                checkedTrackColor = accentColor,
            ),
        )
    }
}

@Composable
private fun SaveProfileDialog(
    initialName: String,
    accentColor: Color,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var profileName by remember { mutableStateOf(initialName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Save Custom Launcher") },
        text = {
            OutlinedTextField(
                value = profileName,
                onValueChange = { profileName = it },
                label = { Text("Profile Name") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("save_profile_name_input"),
            )
        },
        confirmButton = {
            Button(
                onClick = { onSave(profileName) },
                enabled = profileName.trim().isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                modifier = Modifier.testTag("confirm_save_profile_button"),
            ) {
                Text("Save & Activate")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}
