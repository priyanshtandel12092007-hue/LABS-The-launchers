package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LabsDatabase
import com.example.data.local.LauncherPreferences
import com.example.data.model.BackgroundStyle
import com.example.data.model.InstalledApp
import com.example.data.model.LauncherProfile
import com.example.data.model.StarterPresets
import com.example.data.repository.LauncherRepository
import com.example.data.repository.PackageManagerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppMode {
    HOME_LAUNCHER,
    LAUNCHER_STUDIO,
}

data class LauncherUiState(
    val appMode: AppMode = AppMode.HOME_LAUNCHER,
    val activeProfile: LauncherProfile = StarterPresets.labsDefault,
    val studioDraftProfile: LauncherProfile = StarterPresets.labsDefault,
    val savedProfiles: List<LauncherProfile> = StarterPresets.all,
    val installedApps: List<InstalledApp> = emptyList(),
    val homeGridApps: List<InstalledApp> = emptyList(),
    val dockApps: List<InstalledApp> = emptyList(),
    val pinnedHomePackages: Set<String> = emptySet(),
    val pinnedDockPackages: Set<String> = emptySet(),
    val hiddenPackages: Set<String> = emptySet(),
    val isDefaultLauncher: Boolean = false,
    val isDefaultBannerDismissed: Boolean = false,
    val isDrawerOpen: Boolean = false,
    val focusDrawerSearch: Boolean = false,
    val drawerSearchQuery: String = "",
    val showHiddenInDrawer: Boolean = false,
    val showHomeQuickMenu: Boolean = false,
    val showWallpaperSheet: Boolean = false,
    val selectedAppForActions: InstalledApp? = null,
    val isLoadingApps: Boolean = true,
    val statusMessage: String? = null,
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val packageRepo = PackageManagerRepository(application)
    private val launcherRepo = LauncherRepository(
        dao = LabsDatabase.getInstance(application).launcherDao(),
        prefs = LauncherPreferences(application),
    )

    private val installedAppsFlow = MutableStateFlow<List<InstalledApp>>(emptyList())
    private val isLoadingAppsFlow = MutableStateFlow(true)
    private val isDefaultLauncherFlow = MutableStateFlow(packageRepo.isDefaultLauncher())
    private val appModeFlow = MutableStateFlow(AppMode.HOME_LAUNCHER)
    private val draftProfileFlow = MutableStateFlow<LauncherProfile?>(null)
    private val drawerOpenFlow = MutableStateFlow(false)
    private val focusDrawerSearchFlow = MutableStateFlow(false)
    private val drawerSearchQueryFlow = MutableStateFlow("")
    private val showHiddenInDrawerFlow = MutableStateFlow(false)
    private val showHomeQuickMenuFlow = MutableStateFlow(false)
    private val showWallpaperSheetFlow = MutableStateFlow(false)
    private val selectedAppFlow = MutableStateFlow<InstalledApp?>(null)
    private val statusMessageFlow = MutableStateFlow<String?>(null)

    private data class OverlayState(
        val appMode: AppMode,
        val isDrawerOpen: Boolean,
        val focusDrawerSearch: Boolean,
        val drawerSearchQuery: String,
        val showHiddenInDrawer: Boolean,
        val showHomeQuickMenu: Boolean,
        val showWallpaperSheet: Boolean,
        val selectedApp: InstalledApp?,
        val statusMessage: String?,
    )

    private val overlayFlow = combine(
        appModeFlow,
        drawerOpenFlow,
        focusDrawerSearchFlow,
        drawerSearchQueryFlow,
        showHiddenInDrawerFlow,
    ) { mode, drawerOpen, focusSearch, query, showHidden ->
        OverlayState(
            appMode = mode,
            isDrawerOpen = drawerOpen,
            focusDrawerSearch = focusSearch,
            drawerSearchQuery = query,
            showHiddenInDrawer = showHidden,
            showHomeQuickMenu = false,
            showWallpaperSheet = false,
            selectedApp = null,
            statusMessage = null,
        )
    }.combine(
        combine(
            showHomeQuickMenuFlow,
            showWallpaperSheetFlow,
            selectedAppFlow,
            statusMessageFlow,
        ) { quickMenu, wallpaperSheet, selectedApp, status ->
            listOf(quickMenu, wallpaperSheet, selectedApp, status)
        },
    ) { base, extras ->
        base.copy(
            showHomeQuickMenu = extras[0] as Boolean,
            showWallpaperSheet = extras[1] as Boolean,
            selectedApp = extras[2] as InstalledApp?,
            statusMessage = extras[3] as String?,
        )
    }

    val uiState: StateFlow<LauncherUiState> = combine(
        launcherRepo.activeProfile,
        launcherRepo.profiles,
        installedAppsFlow,
        launcherRepo.pinnedApps,
        launcherRepo.hiddenPackageNames,
    ) { active, profiles, apps, pinned, hidden ->
        Triple(active to profiles, apps, pinned to hidden)
    }.combine(
        combine(
            draftProfileFlow,
            isDefaultLauncherFlow,
            launcherRepo.isDefaultBannerDismissed,
            isLoadingAppsFlow,
            overlayFlow,
        ) { draft, isDefault, bannerDismissed, isLoading, overlay ->
            listOf(draft, isDefault, bannerDismissed, isLoading, overlay)
        },
    ) { core, meta ->
        val (active, profiles) = core.first
        val apps = core.second
        val (pinnedList, hiddenSet) = core.third

        val draft = (meta[0] as LauncherProfile?) ?: active
        val isDefault = meta[1] as Boolean
        val bannerDismissed = meta[2] as Boolean
        val isLoading = meta[3] as Boolean
        val overlay = meta[4] as OverlayState

        val appByPkg = apps.associateBy { it.packageName }
        val homePinned = pinnedList.filter { !it.isDock }
            .mapNotNull { appByPkg[it.packageName] }
            .filter { it.packageName !in hiddenSet }
        val dockPinned = pinnedList.filter { it.isDock }
            .mapNotNull { appByPkg[it.packageName] }
            .filter { it.packageName !in hiddenSet }

        LauncherUiState(
            appMode = overlay.appMode,
            activeProfile = active,
            studioDraftProfile = draft,
            savedProfiles = profiles,
            installedApps = apps,
            homeGridApps = homePinned,
            dockApps = dockPinned,
            pinnedHomePackages = pinnedList.filter { !it.isDock }.map { it.packageName }.toSet(),
            pinnedDockPackages = pinnedList.filter { it.isDock }.map { it.packageName }.toSet(),
            hiddenPackages = hiddenSet,
            isDefaultLauncher = isDefault,
            isDefaultBannerDismissed = bannerDismissed,
            isDrawerOpen = overlay.isDrawerOpen,
            focusDrawerSearch = overlay.focusDrawerSearch,
            drawerSearchQuery = overlay.drawerSearchQuery,
            showHiddenInDrawer = overlay.showHiddenInDrawer,
            showHomeQuickMenu = overlay.showHomeQuickMenu,
            showWallpaperSheet = overlay.showWallpaperSheet,
            selectedAppForActions = overlay.selectedApp,
            isLoadingApps = isLoading,
            statusMessage = overlay.statusMessage,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = LauncherUiState(),
    )

    init {
        refreshInstalledApps()
        viewModelScope.launch {
            packageRepo.observePackageChanges().collect {
                refreshInstalledApps()
            }
        }
    }

    fun refreshSystemState() {
        isDefaultLauncherFlow.value = packageRepo.isDefaultLauncher()
        refreshInstalledApps()
    }

    private fun refreshInstalledApps() {
        viewModelScope.launch {
            val apps = packageRepo.loadLaunchableApps()
            installedAppsFlow.value = apps
            isLoadingAppsFlow.value = false
            launcherRepo.ensureSeeded(apps, packageRepo.ownPackageName())
        }
    }

    fun handleHomeButtonIntent() {
        drawerOpenFlow.value = false
        showHomeQuickMenuFlow.value = false
        showWallpaperSheetFlow.value = false
        selectedAppFlow.value = null
        appModeFlow.value = AppMode.HOME_LAUNCHER
    }

    fun openLauncherStudio() {
        showHomeQuickMenuFlow.value = false
        drawerOpenFlow.value = false
        draftProfileFlow.value = uiState.value.activeProfile
        appModeFlow.value = AppMode.LAUNCHER_STUDIO
    }

    fun returnToHomeLauncher() {
        appModeFlow.value = AppMode.HOME_LAUNCHER
    }

    fun openDrawer(focusSearch: Boolean = false) {
        showHomeQuickMenuFlow.value = false
        focusDrawerSearchFlow.value = focusSearch
        drawerOpenFlow.value = true
    }

    fun closeDrawer() {
        drawerOpenFlow.value = false
        focusDrawerSearchFlow.value = false
        drawerSearchQueryFlow.value = ""
    }

    fun updateDrawerSearch(query: String) {
        drawerSearchQueryFlow.value = query
    }

    fun toggleShowHiddenInDrawer() {
        showHiddenInDrawerFlow.update { !it }
    }

    fun openHomeQuickMenu() {
        showHomeQuickMenuFlow.value = true
    }

    fun closeHomeQuickMenu() {
        showHomeQuickMenuFlow.value = false
    }

    fun openWallpaperSheet() {
        showHomeQuickMenuFlow.value = false
        showWallpaperSheetFlow.value = true
    }

    fun closeWallpaperSheet() {
        showWallpaperSheetFlow.value = false
    }

    fun showAppActions(app: InstalledApp) {
        selectedAppFlow.value = app
    }

    fun dismissAppActions() {
        selectedAppFlow.value = null
    }

    fun launchApp(app: InstalledApp) {
        selectedAppFlow.value = null
        if (app.packageName == packageRepo.ownPackageName()) {
            openLauncherStudio()
            return
        }
        val launched = packageRepo.launchApp(app)
        if (!launched) {
            statusMessageFlow.value = "Unable to launch ${app.label}"
        } else {
            drawerOpenFlow.value = false
        }
    }

    fun openAppInfo(packageName: String) {
        selectedAppFlow.value = null
        packageRepo.openAppInfo(packageName)
    }

    fun uninstallApp(packageName: String) {
        selectedAppFlow.value = null
        packageRepo.uninstallApp(packageName)
    }

    fun pinToHome(packageName: String) {
        selectedAppFlow.value = null
        viewModelScope.launch {
            launcherRepo.pinToHome(packageName)
            statusMessageFlow.value = "Pinned to Home"
        }
    }

    fun pinToDock(packageName: String) {
        selectedAppFlow.value = null
        viewModelScope.launch {
            launcherRepo.pinToDock(packageName)
            statusMessageFlow.value = "Pinned to Dock"
        }
    }

    fun unpinApp(packageName: String) {
        selectedAppFlow.value = null
        viewModelScope.launch {
            launcherRepo.unpinApp(packageName)
            statusMessageFlow.value = "Removed from Home"
        }
    }

    fun hideApp(packageName: String) {
        selectedAppFlow.value = null
        viewModelScope.launch {
            launcherRepo.hideApp(packageName)
            statusMessageFlow.value = "Hidden from App Drawer"
        }
    }

    fun unhideApp(packageName: String) {
        selectedAppFlow.value = null
        viewModelScope.launch {
            launcherRepo.unhideApp(packageName)
            statusMessageFlow.value = "Restored to App Drawer"
        }
    }

    fun openHomeSettings() {
        showHomeQuickMenuFlow.value = false
        packageRepo.openHomeSettings()
    }

    fun openSystemSettings() {
        showHomeQuickMenuFlow.value = false
        packageRepo.openSystemSettings()
    }

    fun openSystemWallpaperPicker() {
        showWallpaperSheetFlow.value = false
        showHomeQuickMenuFlow.value = false
        packageRepo.openSystemWallpaperPicker()
    }

    fun dismissDefaultBanner() {
        viewModelScope.launch {
            launcherRepo.dismissDefaultBanner()
        }
    }

    // Studio Draft & Profile Operations
    fun updateDraft(transform: (LauncherProfile) -> LauncherProfile) {
        val current = draftProfileFlow.value ?: uiState.value.activeProfile
        draftProfileFlow.value = transform(current)
    }

    fun selectProfile(profile: LauncherProfile) {
        draftProfileFlow.value = profile
        viewModelScope.launch {
            launcherRepo.selectProfile(profile.id)
        }
    }

    fun applyDraftToHome(goHome: Boolean = true) {
        val draft = draftProfileFlow.value ?: return
        viewModelScope.launch {
            val saved = if (draft.isPreset) {
                val presetMatch = StarterPresets.all.find { it.id == draft.id }
                if (presetMatch == draft) {
                    launcherRepo.selectProfile(draft.id)
                    draft
                } else {
                    launcherRepo.saveProfileAsNew("${draft.name} Custom", draft, activateImmediately = true)
                }
            } else {
                launcherRepo.saveProfile(draft, activateImmediately = true)
            }
            draftProfileFlow.value = saved
            statusMessageFlow.value = "Applied \"${saved.name}\""
            if (goHome) {
                appModeFlow.value = AppMode.HOME_LAUNCHER
            }
        }
    }

    fun saveDraftAsNewProfile(name: String) {
        val draft = draftProfileFlow.value ?: uiState.value.activeProfile
        viewModelScope.launch {
            val saved = launcherRepo.saveProfileAsNew(name, draft, activateImmediately = true)
            draftProfileFlow.value = saved
            statusMessageFlow.value = "Saved profile \"${saved.name}\""
        }
    }

    fun deleteProfile(profileId: String) {
        viewModelScope.launch {
            launcherRepo.deleteCustomProfile(profileId)
            draftProfileFlow.value = null
            statusMessageFlow.value = "Deleted profile"
        }
    }

    fun quickSetBackground(style: BackgroundStyle, customHex: Long? = null) {
        viewModelScope.launch {
            val current = uiState.value.activeProfile
            val updated = current.copy(
                backgroundStyle = style,
                customBackgroundHex = customHex ?: current.customBackgroundHex,
            )
            val saved = if (current.isPreset) {
                launcherRepo.saveProfileAsNew("${current.name} Mix", updated, activateImmediately = true)
            } else {
                launcherRepo.saveProfile(updated, activateImmediately = true)
            }
            draftProfileFlow.value = saved
            showWallpaperSheetFlow.value = false
            statusMessageFlow.value = "Wallpaper updated"
        }
    }

    fun clearStatusMessage() {
        statusMessageFlow.value = null
    }
}
